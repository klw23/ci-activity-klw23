
import { CalculatorModel } from './index';

describe('week4-tdd', (): void => {

  describe('CalculatorModel', (): void => {

    it('should contain a CalculatorModel class that implements ICalculatorModel', (): void => {
      expect(CalculatorModel).toBeDefined();
    });

  });

});
